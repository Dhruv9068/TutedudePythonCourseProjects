import requests
import re
import os

user = input("enter the image name: ")
user_agent = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36"
}

url = f"https://www.google.com/search?q={user}&source=lnms&tbm=isch&sa=X&ved=2ahUKEwjfx7KyqebuAhUQOSSKHC17DsEQ_AUoAXoECBgQAw&biw=1536&bih=760"

response = requests.get(url=url, headers=user_agent).text
pattern = r'"https://[^"]+\.jpg"'

images = re.findall(pattern, response)
print(f"Total Images: {len(images)}")
no_of_images = int(input("Number of images to be downloaded:"))

if images:
    if not os.path.exists(user):
        os.mkdir(user)
    os.chdir(user)

    for i, image_url in enumerate(images[:no_of_images]):
        image_url = image_url[1:-1]  # Remove double quotes from the edges
        try:
            response = requests.get(url=image_url)
            if response.status_code == 200:
                with open(f"{user}_image_{i}.jpg", "wb") as file:
                    file.write(response.content)
                print(f"Downloaded image {i + 1}")
            else:
                print(f"Failed to download image {i + 1}")
        except Exception as e:
            print(f"Error downloading image {i + 1}: {str(e)}")
